--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2
-- Dumped by pg_dump version 16.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "WebApp";
--
-- Name: WebApp; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "WebApp" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United Kingdom.1252';


ALTER DATABASE "WebApp" OWNER TO postgres;

\connect "WebApp"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: autoinsertlisttrigger(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.autoinsertlisttrigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Insert into "preferiti" and "wishlist" lists
    INSERT INTO public.liste (username, nome)
    VALUES (NEW.username, 'preferiti'), (NEW.username, 'wishlist');

    RETURN NEW;
END;
$$;


ALTER FUNCTION public.autoinsertlisttrigger() OWNER TO postgres;

--
-- Name: generanuovoid(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.generanuovoid() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.id := (SELECT COALESCE(MAX(id::integer), 0) + 1 FROM public.Videogiochi); -- la funzione coalesce permette di prendere valori non nulli, se ci sono solo quelli
        RETURN NEW;                -- (se la tabella film è vuota) parte dal valore 0 +1 =1, e da li prende il massimo id (quindi 1) e ci aggiunge 1 e così via
END;
$$;


ALTER FUNCTION public.generanuovoid() OWNER TO postgres;

--
-- Name: setlikes(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.setlikes() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.likes := 0;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.setlikes() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: liste; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.liste (
    username character varying(50) NOT NULL,
    nome character varying NOT NULL
);


ALTER TABLE public.liste OWNER TO postgres;

--
-- Name: recensioni; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recensioni (
    videogioco integer NOT NULL,
    username character varying NOT NULL,
    voto integer NOT NULL,
    commento character varying(1024),
    likes integer NOT NULL,
    titolo character varying(400) NOT NULL
);


ALTER TABLE public.recensioni OWNER TO postgres;

--
-- Name: recensioni_likes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recensioni_likes (
    usernamemittente character varying NOT NULL,
    videogioco integer NOT NULL,
    usernamedestinatario character varying NOT NULL
);


ALTER TABLE public.recensioni_likes OWNER TO postgres;

--
-- Name: segnalazioni; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.segnalazioni (
    mittente character varying NOT NULL,
    destinatario character varying NOT NULL,
    videogioco integer NOT NULL,
    stato character varying
);


ALTER TABLE public.segnalazioni OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    username character varying(50) NOT NULL,
    password character varying(64),
    nome character varying(50),
    cognome character varying(50),
    email character varying(50),
    tipo integer,
    domanda character varying,
    risposta character varying
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: usersespulsi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usersespulsi (
    email character varying NOT NULL
);


ALTER TABLE public.usersespulsi OWNER TO postgres;

--
-- Name: videogiochi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.videogiochi (
    id integer NOT NULL,
    titolo character varying(50) NOT NULL,
    descrizione character varying(1024) NOT NULL,
    genere character varying(64) NOT NULL,
    durata integer NOT NULL,
    anno integer NOT NULL,
    valutazione integer,
    trailer character varying(50),
    casamadre character varying
);


ALTER TABLE public.videogiochi OWNER TO postgres;

--
-- Name: videogiochiinliste; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.videogiochiinliste (
    videogioco integer NOT NULL,
    username character varying(50) NOT NULL,
    nome character varying NOT NULL
);


ALTER TABLE public.videogiochiinliste OWNER TO postgres;

--
-- Data for Name: liste; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.liste (username, nome) FROM stdin;
\.
COPY public.liste (username, nome) FROM '$$PATH$$/4891.dat';

--
-- Data for Name: recensioni; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recensioni (videogioco, username, voto, commento, likes, titolo) FROM stdin;
\.
COPY public.recensioni (videogioco, username, voto, commento, likes, titolo) FROM '$$PATH$$/4893.dat';

--
-- Data for Name: recensioni_likes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recensioni_likes (usernamemittente, videogioco, usernamedestinatario) FROM stdin;
\.
COPY public.recensioni_likes (usernamemittente, videogioco, usernamedestinatario) FROM '$$PATH$$/4894.dat';

--
-- Data for Name: segnalazioni; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.segnalazioni (mittente, destinatario, videogioco, stato) FROM stdin;
\.
COPY public.segnalazioni (mittente, destinatario, videogioco, stato) FROM '$$PATH$$/4895.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (username, password, nome, cognome, email, tipo, domanda, risposta) FROM stdin;
\.
COPY public.users (username, password, nome, cognome, email, tipo, domanda, risposta) FROM '$$PATH$$/4890.dat';

--
-- Data for Name: usersespulsi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usersespulsi (email) FROM stdin;
\.
COPY public.usersespulsi (email) FROM '$$PATH$$/4896.dat';

--
-- Data for Name: videogiochi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.videogiochi (id, titolo, descrizione, genere, durata, anno, valutazione, trailer, casamadre) FROM stdin;
\.
COPY public.videogiochi (id, titolo, descrizione, genere, durata, anno, valutazione, trailer, casamadre) FROM '$$PATH$$/4889.dat';

--
-- Data for Name: videogiochiinliste; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.videogiochiinliste (videogioco, username, nome) FROM stdin;
\.
COPY public.videogiochiinliste (videogioco, username, nome) FROM '$$PATH$$/4892.dat';

--
-- Name: videogiochi giochi_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.videogiochi
    ADD CONSTRAINT giochi_pk PRIMARY KEY (id);


--
-- Name: videogiochiinliste giochiinliste_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.videogiochiinliste
    ADD CONSTRAINT giochiinliste_pk PRIMARY KEY (nome, username, videogioco);


--
-- Name: liste liste_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.liste
    ADD CONSTRAINT liste_pk PRIMARY KEY (nome, username);


--
-- Name: recensioni_likes recensioni_likes_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recensioni_likes
    ADD CONSTRAINT recensioni_likes_pk PRIMARY KEY (videogioco, usernamedestinatario, usernamemittente);


--
-- Name: recensioni recensioni_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recensioni
    ADD CONSTRAINT recensioni_pk PRIMARY KEY (videogioco, username);


--
-- Name: segnalazioni segnalazioni_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.segnalazioni
    ADD CONSTRAINT segnalazioni_pk PRIMARY KEY (mittente, destinatario, videogioco);


--
-- Name: users users_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pk PRIMARY KEY (username);


--
-- Name: usersespulsi usersespulsi_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usersespulsi
    ADD CONSTRAINT usersespulsi_pk PRIMARY KEY (email);


--
-- Name: videogiochi before_insert_videogiochi; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER before_insert_videogiochi BEFORE INSERT ON public.videogiochi FOR EACH ROW EXECUTE FUNCTION public.generanuovoid();


--
-- Name: users insert_user_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER insert_user_trigger AFTER INSERT ON public.users FOR EACH ROW EXECUTE FUNCTION public.autoinsertlisttrigger();


--
-- Name: recensioni setlikestrigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER setlikestrigger BEFORE INSERT ON public.recensioni FOR EACH ROW EXECUTE FUNCTION public.setlikes();


--
-- Name: videogiochiinliste fk_giochi; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.videogiochiinliste
    ADD CONSTRAINT fk_giochi FOREIGN KEY (videogioco) REFERENCES public.videogiochi(id);


--
-- Name: recensioni fk_giochi; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recensioni
    ADD CONSTRAINT fk_giochi FOREIGN KEY (videogioco) REFERENCES public.videogiochi(id);


--
-- Name: segnalazioni fk_recensioni; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.segnalazioni
    ADD CONSTRAINT fk_recensioni FOREIGN KEY (videogioco, destinatario) REFERENCES public.recensioni(videogioco, username);


--
-- Name: recensioni fk_username; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recensioni
    ADD CONSTRAINT fk_username FOREIGN KEY (username) REFERENCES public.users(username);


--
-- Name: videogiochiinliste giochiinliste_liste_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.videogiochiinliste
    ADD CONSTRAINT giochiinliste_liste_fk FOREIGN KEY (username, nome) REFERENCES public.liste(username, nome);


--
-- Name: recensioni_likes recensioni_likes_recensioni_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recensioni_likes
    ADD CONSTRAINT recensioni_likes_recensioni_fk FOREIGN KEY (videogioco, usernamedestinatario) REFERENCES public.recensioni(videogioco, username);


--
-- Name: recensioni_likes recensioni_likes_users_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recensioni_likes
    ADD CONSTRAINT recensioni_likes_users_fk FOREIGN KEY (usernamemittente) REFERENCES public.users(username);


--
-- Name: segnalazioni segnalazioni_users_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.segnalazioni
    ADD CONSTRAINT segnalazioni_users_fk FOREIGN KEY (mittente) REFERENCES public.users(username);


--
-- Name: liste username; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.liste
    ADD CONSTRAINT username FOREIGN KEY (username) REFERENCES public.users(username);


--
-- PostgreSQL database dump complete
--

